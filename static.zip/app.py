
from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from mysql.connector import Error
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

#data_base_connection
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '12345678',
    'database': 'shop_db',
    'raise_on_warnings': True
}


def get_db_connection():
    conn = mysql.connector.connect(**DB_CONFIG)
    return conn

#get_user
def get_current_user():
    if 'user_email' in session:
        try:
            return {'email': session['user_email'], 'user_type': int(session.get('user_type', 0))}
        except Exception:
            return {'email': session['user_email'], 'user_type': 0}
    return None

#main window
@app.route('/')
def index():
    q = request.args.get('q', '')
    cat = request.args.get('category')
    price_min = request.args.get('price_min')
    price_max = request.args.get('price_max')
    sort = request.args.get('sort')  # 'time'|'price_desc'|'alpha'

    sql = "SELECT p.product_id, p.name, p.price, p.rating, p.review_count, p.description, pi.image_url, c.category_name FROM product p LEFT JOIN product_image pi ON p.product_id=pi.product_id LEFT JOIN category c ON p.category_id=c.category_id WHERE 1=1"
    params = []
    if q:
        sql += " AND p.name LIKE %s"
        params.append('%' + q + '%')
    if cat:
        sql += " AND c.category_id = %s"
        params.append(cat)
    if price_min:
        sql += " AND p.price >= %s"
        params.append(price_min)
    if price_max:
        sql += " AND p.price <= %s"
        params.append(price_max)

    if sort == 'price_desc':
        sql += " ORDER BY p.price DESC"
    elif sort == 'alpha':
        sql += " ORDER BY p.name ASC"
    else:
        sql += " ORDER BY p.product_id DESC"

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute(sql, params)
    products = cur.fetchall()

    # categories
    cur.execute("SELECT * FROM category")
    categories = cur.fetchall()
    cur.close()
    conn.close()

    return render_template('index.html', products=products, categories=categories, user=get_current_user())

# register
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        fname = request.form['fname']
        lname = request.form.get('lname', '')
        password = request.form['password']
        role = request.form.get('role', 'buyer')

        conn = get_db_connection()
        cur = conn.cursor()
        try:
            if role == 'buyer':
                cur.callproc('register_buyer', [email, fname, lname, password])
            else:
                # seller
                company = request.form.get('company', '')
                url = request.form.get('url', '')
                desc = request.form.get('description', '')
                cur.callproc('register_seller', [email, fname, lname, password, company, url, desc])
            conn.commit()
            flash('ثبت‌نام با موفقیت انجام شد. لطفا وارد شوید.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            conn.rollback()
            flash('خطا در ثبت‌نام: ' + str(e), 'danger')
        finally:
            cur.close()
            conn.close()

    return render_template('register.html')

# login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)
        cur.execute('SELECT email, password, user_type FROM shop_user WHERE email = %s', (email,))
        row = cur.fetchone()
        cur.close()
        conn.close()
        if row and row['password'] == password:
            session['user_email'] = row['email']
            # ensure stored as int
            try:
                session['user_type'] = int(row.get('user_type', 0))
            except Exception:
                session['user_type'] = 0

            # merge session cart into db cart if needed
            if 'cart' in session and session['cart']:
                try:
                    conn = get_db_connection()
                    cur = conn.cursor()
                    for pid in session['cart']:
                        try:
                            cur.callproc('add_to_shopping_cart', [email, pid])
                        except Exception:
                            pass
                    conn.commit()
                    cur.close()
                    conn.close()
                    session.pop('cart')
                except Exception:
                    pass

            flash('ورود موفق', 'success')
            # redirect based on role
            try:
                if int(session.get('user_type', 0)) == 1:
                    return redirect(url_for('seller_dashboard'))
                elif int(session.get('user_type', 0)) == 2:
                    return redirect(url_for('admin_dashboard'))
            except Exception:
                pass
            return redirect(url_for('index'))
        else:
            flash('ایمیل یا رمز عبور اشتباه است.', 'danger')
    return render_template('login.html')

#logout
@app.route('/logout')
def logout():
    session.clear()
    flash('خروج انجام شد', 'info')
    return redirect(url_for('index'))

# product_page
@app.route('/product/<int:product_id>')
def product_detail(product_id):
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute('SELECT p.*, c.category_name FROM product p LEFT JOIN category c ON p.category_id=c.category_id WHERE p.product_id = %s', (product_id,))
    product = cur.fetchone()
    cur.execute('SELECT image_url FROM product_image WHERE product_id = %s', (product_id,))
    images = [r['image_url'] for r in cur.fetchall()]
    cur.execute('SELECT r.*, s.fname, s.lname FROM review r LEFT JOIN shop_user s ON r.buyer_id = s.email WHERE product_id = %s ORDER BY review_date DESC', (product_id,))
    reviews = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('product.html', product=product, images=images, reviews=reviews, user=get_current_user())

# add_to cart
@app.route('/add_to_cart/<int:product_id>')
def add_to_cart(product_id):
    user = get_current_user()

  
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT available_units FROM product WHERE product_id = %s", (product_id,))
    result = cur.fetchone()

    if not result or result[0] <= 0:
        flash('این محصول در حال حاضر موجود نیست', 'danger')
        cur.close()
        conn.close()
        return redirect(url_for('index'))

    available_units = result[0]  
    cur.close()
    conn.close()

    if not user:
        # session-based cart
        cart = session.get('cart', [])
        if product_id not in cart:
            cart.append(product_id)
        session['cart'] = cart
        flash('محصول به سبد اضافه شد (قبل از ورود)', 'success')
        return redirect(url_for('index'))
    else:
        
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            cur.callproc('add_to_shopping_cart', [user['email'], product_id])
            conn.commit()
            cur.close()
            conn.close()
            flash('محصول به سبد اضافه شد', 'success')
        except Exception as e:
            flash('خطا: ' + str(e), 'danger')
        return redirect(url_for('index'))


#cart
@app.route('/cart')
def cart():
    user = get_current_user()
    products = []
    if not user:
        cart = session.get('cart', [])
        if cart:
            conn = get_db_connection()
            cur = conn.cursor(dictionary=True)
            format_strings = ','.join(['%s'] * len(cart))
            cur.execute(f"SELECT p.product_id, p.name, p.price, pi.image_url FROM product p LEFT JOIN product_image pi ON p.product_id=pi.product_id WHERE p.product_id IN ({format_strings})", tuple(cart))
            products = cur.fetchall()
            cur.close()
            conn.close()
    else:
        
        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT p.product_id, p.name, p.price, pi.image_url FROM product_shoppingcart psc JOIN product p ON psc.product_id = p.product_id LEFT JOIN product_image pi ON p.product_id = pi.product_id WHERE psc.buyer_id = %s", (user['email'],))
        products = cur.fetchall()
        cur.close()
        conn.close()
    return render_template('cart.html', products=products, user=user)

#checkout
@app.route('/checkout', methods=['POST'])
def checkout():
    user = get_current_user()
    if not user:
        flash('برای پرداخت باید وارد شوید', 'warning')
        return redirect(url_for('login'))
    discount_code = request.form.get('discount_code')
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.callproc('place_order', [user['email']])
        conn.commit()
        cur.close()
        conn.close()
        flash('سفارش شما ثبت شد', 'success')
    except Exception as e:
        flash('خطا در ثبت سفارش: ' + str(e), 'danger')
    return redirect(url_for('index'))


   #check default card
    try:
        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT card_id
            FROM card_info
            WHERE buyer_id = %s AND is_default = 1
            LIMIT 1
        """, (user['email'],))
        card_row = cur.fetchone()

        #check default address
        cur.execute("""
            SELECT address_id
            FROM contact_detail
            WHERE user_id = %s AND is_default = 1
            LIMIT 1
        """, (user['email'],))
        addr_row = cur.fetchone()

        cur.close()
        conn.close()

        if not card_row:
            flash('هیچ کارت پرداخت پیش‌فرضی ندارید. لطفاً یک کارت اضافه کنید یا کارتی را به عنوان پیش‌فرض انتخاب کنید.', 'warning')
            return redirect(url_for('profile'))  

        if not addr_row:
            flash('هیچ آدرس تحویل پیش‌فرضی ندارید. لطفاً یک آدرس اضافه کنید یا آدرسی را به عنوان پیش‌فرض انتخاب کنید.', 'warning')
            return redirect(url_for('profile'))  

    except Exception as e:
        flash('خطا در بررسی اطلاعات پرداخت/آدرس: ' + str(e), 'danger')
        return redirect(url_for('cart'))

    
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.callproc('place_order', [user['email']])
        
        
        
        if discount_code:
            try:
                cur.callproc('apply_discount_to_order_by_buyer', [user['email'], order_id, discount_code])
            except Exception as e:
                flash('کد تخفیف نامعتبر است یا قبلاً استفاده شده.', 'warning')

        conn.commit()
        cur.close()
        conn.close()
        flash('سفارش شما ثبت شد', 'success')
        return redirect(url_for('index'))
    except Exception as e:
        
        flash('خطا در ثبت سفارش: ' + str(e), 'danger')
        return redirect(url_for('cart'))

#review
@app.route('/review', methods=['POST'])
def review():
    user = get_current_user()
    if not user:
        flash('برای ثبت نظر باید وارد شوید', 'warning')
        return redirect(url_for('login'))
    product_id = request.form.get('product_id')
    review_text = request.form.get('review_text')
    rating = request.form.get('rating')
    image_url = request.form.get('image_url', '')
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.callproc('give_review', [product_id, user['email'], review_text, rating, image_url])
        conn.commit()
        cur.close()
        conn.close()
        flash('نظر ثبت شد', 'success')
    except Exception as e:
        flash('خطا: ' + str(e), 'danger')
    return redirect(url_for('product_detail', product_id=product_id))

# profile
@app.route('/profile')
def profile():
    user = get_current_user()
    if not user:
        flash('ابتدا وارد شوید', 'warning')
        return redirect(url_for('login'))

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

 
    cur.execute('SELECT * FROM shop_user WHERE email = %s', (user['email'],))
    u = cur.fetchone()
    cur.execute('SELECT * FROM contact_detail WHERE user_id = %s', (user['email'],))
    contacts = cur.fetchall()
    cur.execute('SELECT * FROM card_info WHERE buyer_id = %s', (user['email'],))
    cards = cur.fetchall()

   #orders
    cur.execute('SELECT * FROM shop_order WHERE buyer_id = %s ORDER BY order_date DESC', (user['email'],))
    raw_orders = cur.fetchall()
    orders = []
    for o in raw_orders:
        order_date_str = o['order_date'].strftime('%Y-%m-%d %H:%M') if (o.get('order_date') is not None) else None

        
        delivery_addr = None
        if o.get('delivery_address_id'):
            cur.execute('SELECT * FROM contact_detail WHERE address_id = %s', (o['delivery_address_id'],))
            delivery_addr = cur.fetchone()
            if delivery_addr:
                street2 = delivery_addr.get('street2') or ''
                full_addr = f"{delivery_addr.get('street1','')}{', ' + street2 if street2 else ''}, {delivery_addr.get('city','')}, {delivery_addr.get('state','')}, {delivery_addr.get('country','')} - {delivery_addr.get('zipcode','')}"
                delivery_addr['full_address'] = full_addr

        
        card_info = None
        card_last4 = None
        if o.get('card_id'):
            cur.execute('SELECT * FROM card_info WHERE card_id = %s', (o['card_id'],))
            card_info = cur.fetchone()
            if card_info and card_info.get('card_number') is not None:
                try:
                    card_last4 = str(card_info.get('card_number'))[-4:]
                except Exception:
                    card_last4 = None

        
        cur.execute('''
            SELECT p.product_id, p.name, p.price, op.quantity
            FROM order_product op
            JOIN product p ON op.product_id = p.product_id
            WHERE op.order_id = %s
        ''', (o['order_id'],))
        prods = cur.fetchall() or []

        orders.append({
            'order_id': o.get('order_id'),
            'total_price': o.get('total_price'),
            'order_date': o.get('order_date'),
            'order_date_str': order_date_str,
            'order_status': o.get('order_status'),
            'delivery_address': delivery_addr,
            'card': card_info,
            'card_last4': card_last4,
            'products': prods
        })

    cur.close()
    conn.close()
    return render_template('profile.html', user=u, contacts=contacts, cards=cards, orders=orders)




#add card
@app.route('/add_card', methods=['GET', 'POST'])
def add_card():
    user = get_current_user()
    if not user:
        flash('ابتدا وارد شوید', 'warning')
        return redirect(url_for('login'))
    if request.method == 'POST':
        card_number = request.form.get('card_number')
        expiry_date = request.form.get('expiry_date')  # expected YYYY-MM-DD
        cvv = request.form.get('cvv')
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            # stored procedure: add_card_info 
            cur.callproc('add_card_info', [user['email'], int(card_number), expiry_date, int(cvv)])
            conn.commit()
            cur.close()
            conn.close()
            flash('کارت با موفقیت افزوده شد', 'success')
            return redirect(url_for('profile'))
        except Exception as e:
            flash('خطا در افزودن کارت: ' + str(e), 'danger')
            return redirect(url_for('add_card'))
    return render_template('add_card.html', user=get_current_user())

@app.route('/add_address', methods=['GET', 'POST'])
def add_address():
    user = get_current_user()
    if not user:
        flash('ابتدا وارد شوید', 'warning')
        return redirect(url_for('login'))
    if request.method == 'POST':
        street1 = request.form.get('street1')
        street2 = request.form.get('street2')
        city = request.form.get('city')
        state = request.form.get('state')
        country = request.form.get('country')
        zipcode = request.form.get('zipcode')
        phone = request.form.get('phone')
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            # stored procedure: add_contact_details 
            cur.callproc('add_contact_details', [user['email'], street1, street2, city, state, country, int(zipcode), phone])
            conn.commit()
            cur.close()
            conn.close()
            flash('آدرس با موفقیت افزوده شد', 'success')
            return redirect(url_for('profile'))
        except Exception as e:
            flash('خطا در افزودن آدرس: ' + str(e), 'danger')
            return redirect(url_for('add_address'))
    return render_template('add_address.html', user=get_current_user())

# set a card as default
@app.route('/set_default_card', methods=['POST'])
def set_default_card():
    user = get_current_user()
    if not user:
        flash('ابتدا وارد شوید', 'warning')
        return redirect(url_for('login'))
    card_id = request.form.get('card_id')
    if not card_id:
        flash('شناسه کارت نامعتبر است', 'danger')
        return redirect(url_for('profile'))
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.callproc('set_default_card_info', [int(card_id), user['email']])
        conn.commit()
        cur.close()
        conn.close()
        flash('کارت پیش‌فرض تنظیم شد', 'success')
    except Exception as e:
        flash('خطا در تنظیم کارت پیش‌فرض: ' + str(e), 'danger')
    return redirect(url_for('profile'))

# Route to set an address as default
@app.route('/set_default_address', methods=['POST'])
def set_default_address():
    user = get_current_user()
    if not user:
        flash('ابتدا وارد شوید', 'warning')
        return redirect(url_for('login'))
    address_id = request.form.get('address_id')
    if not address_id:
        flash('شناسه آدرس نامعتبر است', 'danger')
        return redirect(url_for('profile'))
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.callproc('set_default_contact_details', [int(address_id), user['email']])
        conn.commit()
        cur.close()
        conn.close()
        flash('آدرس پیش‌فرض تنظیم شد', 'success')
    except Exception as e:
        flash('خطا در تنظیم آدرس پیش‌فرض: ' + str(e), 'danger')
    return redirect(url_for('profile'))


#seller main dashbord
@app.route('/seller')
def seller_dashboard():
    user = get_current_user()
    if not user or user['user_type'] != 1:
        flash('دسترسی فروشنده لازم است', 'danger')
        return redirect(url_for('login'))

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)


    cur.execute('SELECT * FROM product WHERE seller_id = %s', (user['email'],))
    products = cur.fetchall()


    cur.execute('''
        SELECT o.order_id, o.order_date, o.order_status, o.total_price,
               p.name AS product_name, op.quantity, p.price AS unit_price
        FROM shop_order o
        JOIN order_product op ON o.order_id = op.order_id
        JOIN product p ON op.product_id = p.product_id
        WHERE p.seller_id = %s
        ORDER BY o.order_date DESC
    ''', (user['email'],))
    orders = cur.fetchall()

    cur.close()
    conn.close()

    return render_template('seller_dashboard.html', user=user,products=products, orders=orders)

#add_product
@app.route('/seller/add', methods=['GET', 'POST'])
def seller_add_product():
    user = get_current_user()
    if not user or user['user_type'] != 1:
        flash('دسترسی فروشنده لازم است', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = request.form['name']
        price = request.form['price']
        category_id = request.form.get('category_id')
        description = request.form.get('description')
        available_units = request.form.get('available_units')
        color = request.form.get('color')
        weight = request.form.get('weight')
        carrier_id = request.form.get('carrier_id')
        image_url = request.form.get('image_url')
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            cur.callproc('add_product', [name, user['email'], price, category_id, description, None, available_units, color, weight, carrier_id, image_url])
            conn.commit()
            cur.close()
            conn.close()
            flash('محصول افزوده شد', 'success')
            return redirect(url_for('seller_dashboard'))
        except Exception as e:
            flash('خطا: ' + str(e), 'danger')
    
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute('SELECT * FROM category')
    categories = cur.fetchall()
    cur.execute('SELECT * FROM carrier')
    carriers = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('add_product.html', categories=categories, carriers=carriers)

# admin dashboard
@app.route('/admin')
def admin_dashboard():
    user = get_current_user()
    if not user or user['user_type'] != 2:
        flash('دسترسی ادمین لازم است', 'danger')
        return redirect(url_for('login'))
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute('SELECT * FROM shop_user')
    users = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('admin_dashboard.html',user=user, users=users)

#admin_orders
@app.route('/admin/orders')
def admin_orders():
    user = get_current_user()
    if not user or user['user_type'] != 2:
        flash('دسترسی ادمین لازم است', 'danger')
        return redirect(url_for('login'))

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    query = """
        SELECT 
            o.order_id,
            o.order_date,
            o.total_price,
            o.order_status,
            
            p.name,
            op.quantity
        FROM shop_order o
        JOIN buyer b ON o.buyer_id = b.buyer_id
        JOIN order_product op ON o.order_id = op.order_id
        JOIN product p ON op.product_id = p.product_id
        ORDER BY o.order_date DESC
    """
    cur.execute(query)
    orders = cur.fetchall()

    cur.close()
    conn.close()

    return render_template('admin_orders.html', orders=orders,user=user)


#admin set role
@app.route('/admin/set_role', methods=['POST'])
def admin_set_role():
    user = get_current_user()
    if not user or user['user_type'] != 2:
        flash('دسترسی ادمین لازم است', 'danger')
        return redirect(url_for('login'))
    email = request.form['email']
    role = int(request.form['role'])
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE shop_user SET user_type = %s WHERE email = %s', (role, email))
    conn.commit()
    cur.close()
    conn.close()
    flash('نقش کاربر بروزرسانی شد', 'success')
    return redirect(url_for('admin_dashboard'))


#admin ddiscount
@app.route('/admin/create_discount', methods=['GET', 'POST'])
def create_discount():
    user = get_current_user()
    if not user or user['user_type'] != 2:
        flash('دسترسی ادمین لازم است', 'danger')
        return redirect(url_for('login'))

    if request.method == 'POST':
        code = request.form['code']
        description = request.form['description']
        discount_type = request.form['discount_type']
        value = request.form['value']
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        single_use = 1 if 'single_use' in request.form else 0

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO Discount 
            (code, description, discount_type, value, start_date, end_date, is_active, is_single_use)
            VALUES (%s,%s,%s,%s,%s,%s,1,%s)
        """, (code, description, discount_type, value, start_date, end_date, single_use))
        conn.commit()
        cur.close()
        conn.close()
        flash('کد تخفیف با موفقیت ایجاد شد', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('create_discount.html',user=user)


#caintact us
@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')
        # برای سادگی پیغام‌ها در دیتابیس ذخیره نشده‌اند؛ می‌توان جدول جدا ایجاد کرد.
        flash('پیغام شما دریافت شد. از تماس شما متشکریم.', 'success')
        return redirect(url_for('index'))
    return render_template('contact.html')





@app.route('/remove_from_cart/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    user = get_current_user()
    if not user:
        flash('لطفاً وارد شوید', 'warning')
        return redirect(url_for('login'))

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM product_shoppingcart WHERE buyer_id=%s AND product_id=%s", (user['email'], product_id))
    conn.commit()
    cur.close()
    conn.close()

    flash('محصول از سبد حذف شد', 'success')
    return redirect(url_for('cart'))


if __name__ == '__main__':
    app.run(debug=True)
