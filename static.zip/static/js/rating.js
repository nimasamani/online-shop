// rating.js - small helper to click-to-set rating stars
document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.rating-widget').forEach(function(widget){
    const input = widget.querySelector('input.rating-value');
    const stars = widget.querySelectorAll('.star');
    stars.forEach(function(star, idx){
      star.addEventListener('click', function(){
        input.value = idx + 1;
        stars.forEach(function(s, i){ s.classList.toggle('text-warning', i <= idx); });
      });
    });
  });
});