
-- =============================================
-- Authors: Nima Samanipour,Mahdieh Toofani
-- Description: shop database design, consisting of required tables, constraints, procedures and triggers
-- =============================================

-- 1. TABLE DEFINITIONS


-- 1.1 Users
CREATE TABLE shop_user (
    email       VARCHAR(255)       NOT NULL,
    fname       VARCHAR(255)       NOT NULL,
    lname       VARCHAR(255)       NULL,
    password    VARCHAR(30)        NOT NULL,
    user_type   TINYINT            NOT NULL,
    PRIMARY KEY (email)
) ENGINE=InnoDB;

-- 1.2 Contact Details
CREATE TABLE contact_detail (
    address_id   INT               NOT NULL AUTO_INCREMENT,
    user_id      VARCHAR(255)      NOT NULL,
    street1      VARCHAR(255)      NOT NULL,
    street2      VARCHAR(255)      NULL,
    city         VARCHAR(50)       NOT NULL,
    state        VARCHAR(50)       NOT NULL,
    country      VARCHAR(50)       NOT NULL,
    zipcode      INT               NOT NULL,
    phone        VARCHAR(20)       NOT NULL,
    is_default   TINYINT           NOT NULL DEFAULT 0,
    PRIMARY KEY (address_id),
    INDEX idx_contact_user (user_id),
    CONSTRAINT fk_contact_user
      FOREIGN KEY (user_id)
      REFERENCES shop_user(email)
      ON DELETE CASCADE
) ENGINE=InnoDB;

-- 1.3 Buyer
CREATE TABLE buyer (
    buyer_id            VARCHAR(255)      NOT NULL,
    is_prime            TINYINT           NOT NULL DEFAULT 0,
    prime_expiry_date   DATETIME          NULL,
    PRIMARY KEY (buyer_id)
) ENGINE=InnoDB;

-- 1.4 Card Information
CREATE TABLE card_info (
    card_id       INT               NOT NULL AUTO_INCREMENT,
    card_number   BIGINT            NOT NULL,
    expiry_date   DATETIME          NOT NULL,
    cvv           SMALLINT          NOT NULL,
    buyer_id      VARCHAR(255)      NOT NULL,
    is_default    TINYINT           NOT NULL DEFAULT 0,
    PRIMARY KEY (card_id),
    INDEX idx_card_buyer (buyer_id),
    CONSTRAINT fk_card_buyer
      FOREIGN KEY (buyer_id)
      REFERENCES buyer(buyer_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

-- 1.5 Seller
CREATE TABLE seller (
    seller_id        VARCHAR(255)      NOT NULL,
    company_name     VARCHAR(255)      NOT NULL,
    url              VARCHAR(255)      NULL,
    description      VARCHAR(255)      NULL,
    average_rating   DECIMAL(2,1)      NOT NULL DEFAULT 2.5,
    rating_count     INT               NOT NULL DEFAULT 0,
    PRIMARY KEY (seller_id)
) ENGINE=InnoDB;

-- 1.6 Category
CREATE TABLE category (
    category_id     INT               NOT NULL AUTO_INCREMENT,
    category_name   VARCHAR(255)      NOT NULL,
    PRIMARY KEY (category_id)
) ENGINE=InnoDB;

-- 1.7 Carrier
CREATE TABLE carrier (
    carrier_id      INT               NOT NULL AUTO_INCREMENT,
    carrier_name    VARCHAR(255)      NOT NULL,
    carrier_phone   BIGINT            NOT NULL,
    carrier_email   VARCHAR(255)      NOT NULL,
    PRIMARY KEY (carrier_id)
) ENGINE=InnoDB;

-- 1.8 Discount
CREATE TABLE Discount (
    discount_id   INT AUTO_INCREMENT PRIMARY KEY,
    code          VARCHAR(50)       NOT NULL UNIQUE,
    description   VARCHAR(255)      NULL,
    discount_type ENUM('percentage','fixed_amount') NOT NULL,
    value         DECIMAL(10,2)     NOT NULL,
    start_date    DATE              NOT NULL,
    end_date      DATE              NOT NULL,
    is_active     TINYINT(1)        NOT NULL DEFAULT 1,
    is_single_use TINYINT(1) NOT NULL DEFAULT 0,
    is_used TINYINT(1) NOT NULL DEFAULT 0
    
) ENGINE=InnoDB;

-- 1.9 Product
CREATE TABLE product (
    product_id         INT               NOT NULL AUTO_INCREMENT,
    name               VARCHAR(255)      NOT NULL,
    seller_id          VARCHAR(255)      NOT NULL,
    price              DECIMAL(10,2)     NOT NULL,
    rating             DECIMAL(2,1)      NULL,
    review_count       INT               NOT NULL DEFAULT 0,
    category_id        INT               NULL,
    description        VARCHAR(255)      NULL,
    discount_id        INT               NULL,
    available_units    INT               NOT NULL,
    color              VARCHAR(30)       NULL,
    in_stock           TINYINT           NOT NULL DEFAULT 1,
    weight             DECIMAL(10,2)     NULL,
    carrier_id         INT               NULL,
    PRIMARY KEY (product_id),
    INDEX idx_product_seller   (seller_id),
    INDEX idx_product_category (category_id),
    INDEX idx_product_discount (discount_id),
    INDEX idx_product_carrier  (carrier_id),
    CONSTRAINT fk_product_seller
      FOREIGN KEY (seller_id)
      REFERENCES seller(seller_id)
      ON DELETE CASCADE,
    CONSTRAINT fk_product_category
      FOREIGN KEY (category_id)
      REFERENCES category(category_id)
      ON DELETE SET NULL,
    CONSTRAINT fk_product_discount
      FOREIGN KEY (discount_id)
      REFERENCES Discount(discount_id)
      ON DELETE SET NULL
      ON UPDATE CASCADE,
    CONSTRAINT fk_product_carrier
      FOREIGN KEY (carrier_id)
      REFERENCES carrier(carrier_id)
      ON DELETE SET NULL
) ENGINE=InnoDB;

-- 1.10 Product Image
CREATE TABLE product_image (
    product_id   INT               NOT NULL,
    image_url    VARCHAR(255)      NOT NULL,
    PRIMARY KEY (product_id, image_url),
    INDEX idx_pi_product (product_id),
    CONSTRAINT fk_pi_product
      FOREIGN KEY (product_id)
      REFERENCES product(product_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

-- 1.11 Shopping Cart
CREATE TABLE shopping_cart (
    buyer_id     VARCHAR(255)      NOT NULL,
    date_added   DATETIME          NOT NULL,
    INDEX idx_sc_buyer (buyer_id),
    CONSTRAINT fk_sc_buyer
      FOREIGN KEY (buyer_id)
      REFERENCES buyer(buyer_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

-- 1.12 Product-ShoppingCart 
CREATE TABLE product_shoppingcart (
    product_id   INT               NOT NULL,
    buyer_id     VARCHAR(255)      NOT NULL,
    quantity     INT               NOT NULL DEFAULT 1,
    PRIMARY KEY (product_id, buyer_id),
    INDEX idx_psc_product (product_id),
    INDEX idx_psc_buyer   (buyer_id),
    CONSTRAINT fk_psc_product
      FOREIGN KEY (product_id)
      REFERENCES product(product_id)
      ON DELETE CASCADE,
    CONSTRAINT fk_psc_buyer
      FOREIGN KEY (buyer_id)
      REFERENCES buyer(buyer_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;


-- 1.13 Wish List
CREATE TABLE wish_list (
    buyer_id     VARCHAR(255)      NOT NULL,
    date_added   DATETIME          NOT NULL,
    INDEX idx_wl_buyer (buyer_id),
    CONSTRAINT fk_wl_buyer
      FOREIGN KEY (buyer_id)
      REFERENCES buyer(buyer_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

-- 1.14 Product-WishList 
CREATE TABLE product_wishlist (
    product_id   INT               NOT NULL,
    buyer_id     VARCHAR(255)      NOT NULL,
    PRIMARY KEY (product_id, buyer_id),
    INDEX idx_pwl_product (product_id),
    INDEX idx_pwl_buyer   (buyer_id),
    CONSTRAINT fk_pwl_product
      FOREIGN KEY (product_id)
      REFERENCES product(product_id)
      ON DELETE CASCADE,
    CONSTRAINT fk_pwl_buyer
      FOREIGN KEY (buyer_id)
      REFERENCES buyer(buyer_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

-- 1.15 Orders
CREATE TABLE shop_order (
    order_id            INT AUTO_INCREMENT NOT NULL,
    buyer_id            VARCHAR(255)      NOT NULL,
    card_id             INT               NOT NULL,
    total_price         DECIMAL(10,2)     NOT NULL,
    order_date          DATETIME          NOT NULL,
    tax                 DECIMAL(4,2)      NOT NULL DEFAULT 00.00,
    shipping_price      DECIMAL(4,2)      NOT NULL DEFAULT 00.00,
    discount_id         INT               NULL,
    delivery_address_id INT               NOT NULL,
    delivery_date       DATETIME          NULL,
    order_status        CHAR(1)           NOT NULL,
    quantity            INT               NOT NULL,
    PRIMARY KEY (order_id),
    INDEX idx_order_buyer           (buyer_id),
    INDEX idx_order_card            (card_id),
    INDEX idx_order_discount        (discount_id),
    INDEX idx_order_delivery_addr   (delivery_address_id),
    CONSTRAINT fk_order_buyer
      FOREIGN KEY (buyer_id)
      REFERENCES buyer(buyer_id)
      ON DELETE CASCADE,
    CONSTRAINT fk_order_card
      FOREIGN KEY (card_id)
      REFERENCES card_info(card_id)
      ON DELETE CASCADE,
    CONSTRAINT fk_order_discount
      FOREIGN KEY (discount_id)
      REFERENCES Discount(discount_id)
      ON DELETE SET NULL
      ON UPDATE CASCADE,
    CONSTRAINT fk_order_delivery_addr
      FOREIGN KEY (delivery_address_id)
      REFERENCES contact_detail(address_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;


-- 1.16 Order-Product 
CREATE TABLE order_product (
    order_id   INT NOT NULL,
    product_id INT NOT NULL,
    quantity   INT NOT NULL DEFAULT 1,
    PRIMARY KEY (order_id, product_id),
    INDEX idx_op_order   (order_id),
    INDEX idx_op_product (product_id),
    CONSTRAINT fk_op_order
      FOREIGN KEY (order_id)
      REFERENCES shop_order(order_id)
      ON DELETE CASCADE,
    CONSTRAINT fk_op_product
      FOREIGN KEY (product_id)
      REFERENCES product(product_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;


-- 1.17 Review
CREATE TABLE review (
    review_id     INT               NOT NULL AUTO_INCREMENT,
    product_id    INT               NOT NULL,
    buyer_id      VARCHAR(255)      NOT NULL,
    review_text   VARCHAR(1000)     NULL,
    rating        DECIMAL(2,1)      NULL,
    review_date   DATETIME          NOT NULL,
    PRIMARY KEY (review_id),
    INDEX idx_review_product (product_id),
    INDEX idx_review_buyer   (buyer_id),
    CONSTRAINT fk_review_product
      FOREIGN KEY (product_id)
      REFERENCES product(product_id)
      ON DELETE CASCADE,
    CONSTRAINT fk_review_buyer
      FOREIGN KEY (buyer_id)
      REFERENCES buyer(buyer_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

-- 1.18 Review Image
CREATE TABLE review_image (
    review_id   INT               NOT NULL,
    image_url   VARCHAR(255)      NOT NULL,
    PRIMARY KEY (review_id, image_url),
    INDEX idx_ri_review (review_id),
    CONSTRAINT fk_ri_review
      FOREIGN KEY (review_id)
      REFERENCES review(review_id)
      ON DELETE CASCADE
) ENGINE=InnoDB;



-- 2. STORED PROCEDURES


DELIMITER $$

-- 2.1 register_buyer
CREATE PROCEDURE register_buyer (
    IN p_email      VARCHAR(255),
    IN p_fname      VARCHAR(255),
    IN p_lname      VARCHAR(255),
    IN p_password   VARCHAR(30)
)
BEGIN
    INSERT INTO shop_user (email, fname, lname, password, user_type)
    VALUES (p_email, p_fname, p_lname, p_password, 0);

    INSERT INTO buyer (buyer_id, is_prime, prime_expiry_date)
    VALUES (p_email, 0, NULL);
END $$

-- 2.2 register_seller
CREATE PROCEDURE register_seller (
    IN p_email           VARCHAR(255),
    IN p_fname           VARCHAR(255),
    IN p_lname           VARCHAR(255),
    IN p_password        VARCHAR(30),
    IN p_company_name    VARCHAR(255),
    IN p_url             VARCHAR(255),
    IN p_description     VARCHAR(255)
)
BEGIN
    INSERT INTO shop_user (email, fname, lname, password, user_type)
    VALUES (p_email, p_fname, p_lname, p_password, 1);

    INSERT INTO seller (seller_id, company_name, url, description, average_rating, rating_count)
    VALUES (p_email, p_company_name, p_url, p_description, 2.5, 0);
END $$

-- 2.3 add_contact_details
CREATE PROCEDURE add_contact_details (
    IN p_user_id     VARCHAR(255),
    IN p_street1     VARCHAR(255),
    IN p_street2     VARCHAR(255),
    IN p_city        VARCHAR(50),
    IN p_state       VARCHAR(50),
    IN p_country     VARCHAR(50),
    IN p_zipcode     INT,
    IN p_phone       VARCHAR(20)
)
BEGIN
    INSERT INTO contact_detail (user_id, street1, street2, city, state, country, zipcode, phone, is_default)
    VALUES (p_user_id, p_street1, p_street2, p_city, p_state, p_country, p_zipcode, p_phone, 0);
END $$

-- 2.4 set_default_contact_details
CREATE PROCEDURE set_default_contact_details (
    IN p_address_id   INT,
    IN p_buyer_id     VARCHAR(255)
)
BEGIN
    UPDATE contact_detail
    SET is_default = 1
    WHERE user_id = p_buyer_id
      AND address_id = p_address_id;
END $$

-- 2.5 add_card_info
CREATE PROCEDURE add_card_info (
    IN p_buyer_id      VARCHAR(255),
    IN p_card_number   BIGINT,
    IN p_expiry_date   DATE,
    IN p_cvv           SMALLINT
)
BEGIN
    INSERT INTO card_info (card_number, expiry_date, cvv, buyer_id, is_default)
    VALUES (p_card_number, p_expiry_date, p_cvv, p_buyer_id, 0);
END $$

-- 2.6 set_default_card_info
CREATE PROCEDURE set_default_card_info (
    IN p_card_id       INT,
    IN p_buyer_id      VARCHAR(255)
)
BEGIN
    UPDATE card_info
    SET is_default = 1
    WHERE buyer_id = p_buyer_id
      AND card_id = p_card_id;
END $$

-- 2.7 add_product 
CREATE PROCEDURE add_product (
    IN p_name            VARCHAR(255),
    IN p_seller_id       VARCHAR(255),
    IN p_price           DECIMAL(10,2),
    IN p_category_id     INT,
    IN p_description     VARCHAR(255),
    IN p_discount_id     INT,
    IN p_available_units INT,
    IN p_color           VARCHAR(30),
    IN p_weight          DECIMAL(10,2),
    IN p_carrier_id      INT,
    IN p_image_url       VARCHAR(255)
)
BEGIN
    INSERT INTO product (
        name, seller_id, price, rating, review_count,
        category_id, description, discount_id,
        available_units, color, in_stock, weight, carrier_id
    ) VALUES (
        p_name, p_seller_id, p_price, 0, 0,
        p_category_id, p_description, p_discount_id,
        p_available_units, p_color, 1, p_weight, p_carrier_id
    );

    INSERT INTO product_image (product_id, image_url)
    VALUES (LAST_INSERT_ID(), p_image_url);
END $$

-- 2.8 add_to_shopping_cart
DELIMITER $$

CREATE PROCEDURE add_to_shopping_cart (
    IN p_buyer_id   VARCHAR(255),
    IN p_product_id INT
)
BEGIN

    INSERT INTO product_shoppingcart (product_id, buyer_id, quantity)
    VALUES (p_product_id, p_buyer_id, 1)
    ON DUPLICATE KEY UPDATE quantity = quantity + 1;
END $$

DELIMITER $$


-- 2.9 add_to_wish_list
CREATE PROCEDURE add_to_wish_list (
    IN p_buyer_id     VARCHAR(255),
    IN p_product_id   INT
)
BEGIN
    INSERT INTO wish_list (buyer_id, date_added)
    VALUES (p_buyer_id, NOW());

    INSERT INTO product_wishlist (product_id, buyer_id)
    VALUES (p_product_id, p_buyer_id);
END $$



DELIMITER $$
DELIMITER $$
-- 2.10 give_review
CREATE PROCEDURE give_review (
    IN p_product_id   INT,
    IN p_buyer_id     VARCHAR(255),
    IN p_review       VARCHAR(1000),
    IN p_rating       DECIMAL(2,1),
    IN p_image_url    VARCHAR(255)
)
BEGIN
    DECLARE last_review_id INT;

   
    INSERT INTO review (product_id, buyer_id, review_text, rating, review_date)
    VALUES (p_product_id, p_buyer_id, p_review, p_rating, NOW());

    SET last_review_id = LAST_INSERT_ID();

 
    IF p_image_url IS NOT NULL AND TRIM(p_image_url) <> '' THEN
        INSERT INTO review_image (review_id, image_url)
        VALUES (last_review_id, p_image_url);
    END IF;
END $$

DELIMITER $$


CREATE PROCEDURE get_product_reviews (
    IN p_product_id INT
)
BEGIN
    SELECT 
        r.review_id,
        r.review_text,
        r.rating,
        r.review_date,
        u.fname AS buyer_fname,
        u.lname AS buyer_lname,
        p.product_id,
        p.product_name,
        p.seller_id,       
        s.fname AS seller_fname,
        s.lname AS seller_lname,
        ri.image_url
    FROM review r
    JOIN shop_user u ON r.buyer_id = u.email
    JOIN product p ON r.product_id = p.product_id
    JOIN seller s ON p.seller_id = s.seller_id
    LEFT JOIN review_image ri ON r.review_id = ri.review_id
    WHERE r.product_id = p_product_id
    ORDER BY r.review_date DESC;
END $$
DELIMITER $$

-- 2.11 update_membership
CREATE PROCEDURE update_membership (
    IN p_buyer_id     VARCHAR(255)
)
BEGIN
    UPDATE buyer
    SET is_prime = 1,
        prime_expiry_date = DATE_ADD(NOW(), INTERVAL 12 MONTH)
    WHERE buyer_id = p_buyer_id;
END $$

-- 2.12 cancel_membership
CREATE PROCEDURE cancel_membership (
    IN p_buyer_id     VARCHAR(255)
)
BEGIN
    UPDATE buyer
    SET is_prime = 0,
        prime_expiry_date = NULL
    WHERE buyer_id = p_buyer_id;
END $$

-- 2.13 place_order
CREATE PROCEDURE place_order (
    IN p_buyer_id    VARCHAR(255)
)
BEGIN
    DECLARE v_order_id            INT;
    DECLARE v_card_id             INT;
    DECLARE v_address_id          INT;
    DECLARE v_total_price         DECIMAL(10,2) DEFAULT 0.00;
    DECLARE v_curr_price          DECIMAL(10,2);
    DECLARE v_total_qty           INT DEFAULT 0;
    DECLARE v_available_units     INT;
    DECLARE v_shipping_price      DECIMAL(4,2) DEFAULT 10.00;
    DECLARE v_is_prime            TINYINT;
    DECLARE done                  INT DEFAULT 0;


    DECLARE cur_prod CURSOR FOR
        SELECT product_id
        FROM product_shoppingcart
        WHERE buyer_id = p_buyer_id;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

  
    SELECT is_prime INTO v_is_prime
    FROM buyer
    WHERE buyer_id = p_buyer_id;

    IF v_is_prime = 1 THEN
        SET v_shipping_price = 0.00;
    END IF;

    SELECT card_id INTO v_card_id
    FROM card_info
    WHERE buyer_id = p_buyer_id
      AND is_default = 1
    LIMIT 1;

    SELECT address_id INTO v_address_id
    FROM contact_detail
    WHERE user_id = p_buyer_id
      AND is_default = 1
    LIMIT 1;

    INSERT INTO shop_order (
        buyer_id, card_id, total_price, order_date,
        tax, shipping_price, discount_id, delivery_address_id,
        delivery_date, order_status, quantity
    )
    VALUES (
        p_buyer_id, v_card_id, 0.00, NOW(),
        10.00, v_shipping_price, NULL, v_address_id,
        DATE_ADD(NOW(), INTERVAL 1 MONTH), 'c', 0
    );
    SET v_order_id = LAST_INSERT_ID();


    OPEN cur_prod;
    FETCH cur_prod INTO v_curr_price; 
    WHILE done = 0 DO
      
        SET @prod_id = v_curr_price;


        SELECT price, available_units
        INTO v_curr_price, v_available_units
        FROM product
        WHERE product_id = @prod_id
        LIMIT 1;

        IF v_available_units > 0 THEN
            SET v_total_price = v_total_price + v_curr_price;
            SET v_total_qty = v_total_qty + 1;

            INSERT INTO order_product (order_id, product_id)
            VALUES (v_order_id, @prod_id);
        END IF;

        FETCH cur_prod INTO v_curr_price;
    END WHILE;
    CLOSE cur_prod;


    SET v_total_price = v_total_price + v_shipping_price + 10.00;


    UPDATE shop_order
    SET total_price = v_total_price,
        quantity = v_total_qty
    WHERE order_id = v_order_id;


    DELETE sc
    FROM shopping_cart AS sc
    WHERE sc.buyer_id = p_buyer_id;

    DELETE psc
    FROM product_shoppingcart AS psc
    WHERE psc.buyer_id = p_buyer_id;
END $$




-- دریافت پیام‌های ارتباط با ما برای ادمین
DELIMITER $$
CREATE PROCEDURE admin_get_contacts()
BEGIN
    SELECT 
        c.contact_id,
        c.name,
        c.email,
        c.message,
        c.created_at
    FROM contact_us c
    ORDER BY c.created_at DESC;
END$$
DELIMITER $$


-- 2.14 populate_product_categories
CREATE PROCEDURE populate_product_categories()
BEGIN
    INSERT INTO category (category_name) VALUES ('Electronics');
    INSERT INTO category (category_name) VALUES ('Books');
    INSERT INTO category (category_name) VALUES ('Clothing');
END $$

-- 2.15 populate_carriers
CREATE PROCEDURE populate_carriers()
BEGIN
    INSERT INTO carrier (carrier_name, carrier_phone, carrier_email)
    VALUES ('DHL', 1234567890, 'DHL@gmail.com');

    INSERT INTO carrier (carrier_name, carrier_phone, carrier_email)
    VALUES ('Fedex', 1234567890, 'Fedex@gmail.com');

    INSERT INTO carrier (carrier_name, carrier_phone, carrier_email)
    VALUES ('UPS', 1234567890, 'UPS@gmail.com');
END $$




CREATE PROCEDURE apply_discount_to_product_by_buyer (
    IN p_buyer_id    VARCHAR(255),
    IN p_product_id  INT,
    IN p_code        VARCHAR(50)
)
buy_prod_block: BEGIN
    DECLARE v_discount_id INT;
    DECLARE v_type        ENUM('percentage','fixed_amount');
    DECLARE v_value       DECIMAL(10,2);
    DECLARE v_start       DATE;
    DECLARE v_end         DATE;
    DECLARE v_active      TINYINT(1);
    DECLARE v_now         DATE;

    SET v_now = CURDATE();


    IF NOT EXISTS (SELECT 1 FROM product WHERE product_id = p_product_id) THEN
        LEAVE buy_prod_block;
    END IF;

    SELECT discount_id, discount_type, value, start_date, end_date, is_active
    INTO v_discount_id, v_type, v_value, v_start, v_end, v_active
    FROM Discount
    WHERE code = p_code
    LIMIT 1;

    IF v_discount_id IS NULL OR v_active = 0 
       OR v_now < v_start 
       OR v_now > v_end THEN
        LEAVE buy_prod_block;
    END IF;

    UPDATE product
    SET discount_id = v_discount_id
    WHERE product_id = p_product_id;
END buy_prod_block $$

CREATE PROCEDURE apply_discount_to_order_by_buyer (
    IN p_buyer_id    VARCHAR(255),
    IN p_order_id    INT,
    IN p_code        VARCHAR(50)
)
buy_order_block: BEGIN
    DECLARE v_order_buyer  VARCHAR(255);
    DECLARE v_discount_id  INT;
    DECLARE v_type         ENUM('percentage','fixed_amount');
    DECLARE v_value        DECIMAL(10,2);
    DECLARE v_start        DATE;
    DECLARE v_end          DATE;
    DECLARE v_active       TINYINT(1);
    DECLARE v_single_use   TINYINT(1);
    DECLARE v_used         TINYINT(1);
    DECLARE v_now          DATE;

    SET v_now = CURDATE();


    SELECT buyer_id
    INTO v_order_buyer
    FROM shop_order
    WHERE order_id = p_order_id
    LIMIT 1;

    IF v_order_buyer IS NULL OR v_order_buyer <> p_buyer_id THEN
        LEAVE buy_order_block;
    END IF;


    SELECT discount_id, discount_type, value, start_date, end_date, is_active, is_single_use, is_used
    INTO v_discount_id, v_type, v_value, v_start, v_end, v_active, v_single_use, v_used
    FROM Discount
    WHERE code = p_code
    LIMIT 1;


    IF v_discount_id IS NULL OR v_active = 0 
       OR v_now < v_start 
       OR v_now > v_end
       OR (v_single_use = 1 AND v_used = 1) THEN
        LEAVE buy_order_block;
    END IF;


    UPDATE shop_order
    SET discount_id = v_discount_id
    WHERE order_id = p_order_id;


    IF v_single_use = 1 THEN
        UPDATE Discount
        SET is_used = 1
        WHERE discount_id = v_discount_id;
    END IF;
END buy_order_block $$



CREATE PROCEDURE create_discount_for_product (
    IN p_seller_id   VARCHAR(255),
    IN p_product_id  INT,
    IN p_code        VARCHAR(50),
    IN p_description VARCHAR(255),
    IN p_type        ENUM('percentage','fixed_amount'),
    IN p_value       DECIMAL(10,2),
    IN p_start_date  DATE,
    IN p_end_date    DATE
)
proc_prod_block: BEGIN
    DECLARE v_owner   VARCHAR(255);
    DECLARE v_now     DATE;

    SET v_now = CURDATE();

   
    SELECT seller_id
    INTO v_owner
    FROM product
    WHERE product_id = p_product_id
    LIMIT 1;

    IF v_owner IS NULL OR v_owner <> p_seller_id THEN
        LEAVE proc_prod_block;
    END IF;


    IF p_start_date > p_end_date OR p_start_date < v_now THEN
        LEAVE proc_prod_block;
    END IF;


    INSERT INTO Discount (
        code,
        description,
        discount_type,
        value,
        start_date,
        end_date,
        is_active
    ) VALUES (
        p_code,
        p_description,
        p_type,
        p_value,
        p_start_date,
        p_end_date,
        1
    );


    SET @new_discount_id = LAST_INSERT_ID();

    UPDATE product
    SET discount_id = @new_discount_id
    WHERE product_id = p_product_id;
END proc_prod_block $$

CREATE PROCEDURE create_discount_for_order (
    IN p_seller_id   VARCHAR(255),
    IN p_order_id    INT,
    IN p_code        VARCHAR(50),
    IN p_description VARCHAR(255),
    IN p_type        ENUM('percentage','fixed_amount'),
    IN p_value       DECIMAL(10,2),
    IN p_start_date  DATE,
    IN p_end_date    DATE
)
proc_order_block: BEGIN
    DECLARE v_now        DATE;
    DECLARE v_exists     INT;

    SET v_now = CURDATE();

    IF p_start_date > p_end_date OR p_start_date < v_now THEN
        LEAVE proc_order_block;
    END IF;

    
    SELECT COUNT(*) INTO v_exists
    FROM order_product op
    JOIN product pr ON op.product_id = pr.product_id
    WHERE op.order_id = p_order_id
      AND pr.seller_id = p_seller_id;

    IF v_exists = 0 THEN
        LEAVE proc_order_block;
    END IF;


    INSERT INTO Discount (
        code,
        description,
        discount_type,
        value,
        start_date,
        end_date,
        is_active
    ) VALUES (
        p_code,
        p_description,
        p_type,
        p_value,
        p_start_date,
        p_end_date,
        1
    );


    SET @new_discount_id = LAST_INSERT_ID();

  
    UPDATE shop_order
    SET discount_id = @new_discount_id
    WHERE order_id = p_order_id;
END proc_order_block $$

-- Deactivate a discount
CREATE PROCEDURE deactivate_discount (
    IN p_discount_id INT
)
BEGIN
    UPDATE Discount
    SET is_active = 0
    WHERE discount_id = p_discount_id;
END $$


DELIMITER ;



-- 3. TRIGGERS


--  update_product_rating
DELIMITER $$
CREATE TRIGGER trg_update_product_rating
AFTER INSERT ON review
FOR EACH ROW
BEGIN
    DECLARE v_old_count INT;
    DECLARE v_new_rating DECIMAL(2,1);

    SELECT review_count
    INTO v_old_count
    FROM product
    WHERE product_id = NEW.product_id
    LIMIT 1;

    SET v_new_rating = NEW.rating;

    UPDATE product
    SET
        rating = ((rating * v_old_count) + v_new_rating) / (v_old_count + 1),
        review_count = v_old_count + 1
    WHERE product_id = NEW.product_id;
END $$
DELIMITER ;

--  update_seller_rating
DELIMITER $$

CREATE TRIGGER trg_update_seller_rating
AFTER INSERT ON review
FOR EACH ROW
BEGIN
    DECLARE v_new_rating DECIMAL(2,1);
    DECLARE v_seller_id VARCHAR(255);
    DECLARE v_old_count INT;
    DECLARE v_old_avg DECIMAL(2,1);

    SET v_new_rating = NEW.rating;

    SELECT s.seller_id, s.average_rating, s.rating_count
    INTO v_seller_id, v_old_avg, v_old_count
    FROM product p
    JOIN seller s ON p.seller_id = s.seller_id
    WHERE p.product_id = NEW.product_id
    LIMIT 1;

    UPDATE seller
    SET
        average_rating = ((v_old_avg * v_old_count) + v_new_rating) / (v_old_count + 1),
        rating_count = v_old_count + 1
    WHERE seller_id = v_seller_id;
END $$

DELIMITER $$


--  update_available_units
DELIMITER $$
CREATE TRIGGER trg_update_available_units
AFTER INSERT ON order_product
FOR EACH ROW
BEGIN
    UPDATE product AS p
    JOIN order_product AS op ON p.product_id = op.product_id
    SET
        p.available_units = p.available_units - 1,
        p.in_stock = CASE
                        WHEN p.available_units - 1 <= 0 THEN 0
                        ELSE p.in_stock
                     END
    WHERE op.order_id = NEW.order_id
      AND op.product_id = NEW.product_id;
END $$
DELIMITER ;


-- 4. SAMPLE DATA INITIALIZATION


-- 4.1 Register Buyers
CALL register_buyer('samanynym@gmail.com', 'nima', 'samani', 'abcd123');
CALL register_buyer('mahdiehtoofani@gmail.com', 'mahdie', 'toofani', 'abcd123');


-- 4.2 Register Sellers
CALL register_seller(
    'alilotfi@gmail.com', 'arsha', 'toosi', 'abcd123',
    'lotfi Co and Co', 'www.non.com', 'company of shoes'
);
CALL register_seller(
    'arshatooso@gmail.com', 'arsha', 'toosi', 'abcd123',
    'toosi Co and Co', 'www.nonn.com', 'company of metals'
);

-- 4.3 Add Contact Details
CALL add_contact_details('samanynym@gmail.com', '7825 McCallum Blvd', 'Apt 007', 'Dallas', 'Texas', 'USA', 75252, '8888888888');
CALL add_contact_details('samanynym@gmail.com', '7825 McCallum Blvd', 'Apt 1702', 'Dallas', 'Texas', 'USA', 75252, '8888888888');
CALL add_contact_details('mahdiehtoofani@gmail.com', '7825 McCallum Blvd', 'Apt 1702', 'Dallas', 'Texas', 'USA', 75252, '4692309274');

CALL set_default_contact_details(1, 'samanynym@gmail.com');
CALL set_default_contact_details(3, 'mahdiehtoofani@gmail.com');

-- 4.4 Add Card Info
CALL add_card_info('samanynym@gmail.com', 1234123412341234, '2023-12-09', 666);
CALL add_card_info('samanynym@gmail.com', 234123412341234,  '2023-12-09', 777);
CALL add_card_info('mahdiehtoofani@gmail.com', 234123412341234, '2023-12-09', 777);

CALL set_default_card_info(1, 'samanynym@gmail.com');
CALL set_default_card_info(3, 'mahdiehtoofani@gmail.com');

-- 4.5 Populate Categories & Carriers
CALL populate_product_categories();
CALL populate_carriers();


-- 4.7 Add Products 
CALL add_product(
    'OnePlus 7', 'alilotfi@gmail.com', 400.00, 1,
    'Best Phone', NULL, 2, 'Blue', 2.00, 2,
    'bit.ly/sfdf4fg'
);
CALL add_product(
    'Harry Potter', 'alilotfi@gmail.com', 15.00, 2,
    'Best Book', NULL, 5, 'Black', 8.00, 2,
    'bit.ly/sfdf4fg'
);
CALL add_product(
    'Nike Shoes', 'arshatooso@gmail.com', 50.00, 3,
    'Best shoes', NULL, 2, 'Yellow', 5.00, 1,
    'bit.ly/sfdf4fg'
);
CALL add_product(
    'I Phone', 'arshatooso@gmail.com', 500.00, 1,
    'Better than Android', NULL, 3, 'Black', 2.00, 3,
    'bit.ly/sfdf4fg'
);
CALL add_product(
    'Metal Detector', 'arshatooso@gmail.com', 20.00, 1,
    'Best metal detector', NULL, 4, 'Grey', 12.00, 2,
    'bit.ly/sfdf4fg'
);

-- 4.8 Add Wishlist Entries
CALL add_to_wish_list('samanynym@gmail.com', 1);
CALL add_to_wish_list('samanynym@gmail.com', 4);

-- 4.9 Add Shopping Cart Entries
CALL add_to_shopping_cart('samanynym@gmail.com', 1);
CALL add_to_shopping_cart('samanynym@gmail.com', 3);

-- 4.10 Update Membership
CALL update_membership('mahdiehtoofani@gmail.com');

-- 4.11 Place Orders
CALL place_order('samanynym@gmail.com');
CALL place_order('mahdiehtoofani@gmail.com');




CALL create_discount_for_product(
    'alilotfi@gmail.com',   
    1,                         
    'NOWRUZ1404',                
    'ddddddd', 
    'percentage',              
    20.00,                    
    '2025-03-01',              
    '2025-03-31'               
);

CALL create_discount_for_order(
    'arshatooso@gmail.com',  
    2,                         
    'SAVE50K',                
    'desc', 
    'fixed_amount',           
    50000.00,                  
    '2025-03-01',             
    '2025-03-15'               
);
-- 4.13 Deactivate a discount example
CALL deactivate_discount( @new_discount_id );
-- 4.12 Buyer applies discount to product
CALL apply_discount_to_product_by_buyer(
    'samanynym@gmail.com@gmail.com',  
    1,                        
    'NOWRUZ1404'              
);

-- 4.13 Buyer applies discount to order
CALL apply_discount_to_order_by_buyer(
    'samanynym@gmail.com',  
    1,                         
    'SAVE50K'                  
);

INSERT INTO shop_user (email, fname, lname, password, user_type)
VALUES ('admin@example.com', 'Admin', 'Team', 'admin123', 2);


-- End of MySQL Script
