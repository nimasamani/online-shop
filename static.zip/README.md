# Flask Shop (Student Project) - Ready Package

این بسته شامل یک نمونه کامل از وب‌سایت فروشگاه است که با Flask نوشته شده و بر پایه اسکریپت MySQL شما کار می‌کند.

## محتویات
- `app.py` - برنامه اصلی Flask
- `templates/` - قالب‌های HTML
- `static/css/style.css` - استایل سفارشی
- `static/js/rating.js` - JS کوچک برای انتخاب ستاره‌ها (rating)
- `static/img/placeholder.svg` - تصویر جایگزین
- `README.md` - همین فایل
- `requirements.txt` - بسته‌های لازم

## راه‌اندازی سریع
1. محیط مجازی بساز و فعال کن:
   ```bash
   python -m venv venv
   source venv/bin/activate  # لینوکس/مک
   venv\Scripts\activate    # ویندوز (PowerShell)
   ```

2. نصب وابستگی‌ها:
   ```bash
   pip install -r requirements.txt
   ```

3. ایجاد دیتابیس و اجرای اسکریپت SQL:
   - با MySQL به سرور متصل شو و اسکریپت SQL که فرستادی را اجرا کن تا جداول، stored procedures و data نمونه ساخته شوند.
   - نام دیتابیس (مثلاً `shop_db`) را یادداشت کن.

4. ویرایش `app.py`:
   - در ابتدای فایل `DB_CONFIG` را با `host`, `user`, `password`, `database` خودت جایگزین کن.

5. اجرا:
   ```bash
   python app.py
   ```
   سپس مرورگر را باز کن: `http://127.0.0.1:5000`

## نکات
- کلمه عبورها در دیتابیس به صورت متن صریح هستند. برای استفاده امن در پروژه‌ی واقعی، از هش کردن رمزها استفاده کن.
- تصویرهای محصولات در قالب آدرس URL استفاده می‌شوند. اگر می‌خواهی تصویر آپلود کنی باید endpoint و ذخیره‌سازی اضافه شود.
- بخش پرداخت صرفاً یک شبیه‌سازی است و تراکنش واقعی انجام نمی‌شود.
